Dealer & Vehicle Inventory Module
=================================

Overview
--------

This project implements a multi-tenant Dealer and Vehicle inventory module
inside a Modular Monolith Spring Boot application.

Each request must contain a tenant identifier using the HTTP header:

X-Tenant-Id

This ensures tenant isolation so that each tenant can only access their own data.

Technology Stack
----------------

Java 17 
Spring Boot 
Spring Data JPA 
H2 Database 
Lombok 

Architecture
------------

The project follows clean architecture principles with clear separation of responsibilities:

controller → REST endpoints 
service → business logic 
repository → database access 
entity → domain models 
config → tenant handling 

Modules:

dealer 
vehicle 
admin 

Multi-Tenancy
-------------

Multi-tenancy is implemented using a request filter.

The filter reads the X-Tenant-Id header and stores it in a thread-local context.

All database operations include the tenantId to ensure tenant isolation.

Example header:

X-Tenant-Id: tenant1

If the header is missing → HTTP 400 returned.

Cross-tenant access → HTTP 403.

Dealer Endpoints
----------------

POST /dealers

GET /dealers/{id}

GET /dealers?page=0&size=10&sort=name

PATCH /dealers/{id}

DELETE /dealers/{id}

Vehicle Endpoints
-----------------

POST /vehicles

GET /vehicles/{id}

GET /vehicles

Filters supported:

model 
status 
priceMin 
priceMax 

Pagination and sorting are supported.

Special Query
-------------

GET /vehicles?subscription=PREMIUM

Returns vehicles where the dealer subscription type is PREMIUM while still remaining tenant-scoped.

Admin Endpoint
--------------

GET /admin/dealers/countBySubscription

Example response:

{
"BASIC": 10,
"PREMIUM": 3
}

This implementation counts dealers across all tenants.

Running the Project
-------------------

Clone repository

Run:

mvn spring-boot:run

API runs on:

http://localhost:8080

Example Request
---------------

Create Dealer

POST /dealers

Headers:

X-Tenant-Id: tenant1

Body:

{
"name": "Dealer One",
"email": "dealer@email.com",
"subscriptionType": "PREMIUM"
}

Author
------

Souha Demikha
Backend Engineer (Java / Spring Boot)
