package com.example.inventory.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;

import com.example.inventory.domain.Vehicle;
import com.example.inventory.domain.enums.VehicleStatus;

import java.math.BigDecimal;
import java.util.UUID;



/**
* Repository for vehicles.
* JpaSpecificationExecutor enables dynamic filtering.
*/
public interface VehicleRepository extends JpaRepository<Vehicle, UUID>, JpaSpecificationExecutor<Vehicle> {
}
