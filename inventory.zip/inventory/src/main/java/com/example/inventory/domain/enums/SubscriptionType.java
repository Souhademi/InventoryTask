package com.example.inventory.domain.enums;

public enum SubscriptionType {

    BASIC,
    PREMIUM
}
