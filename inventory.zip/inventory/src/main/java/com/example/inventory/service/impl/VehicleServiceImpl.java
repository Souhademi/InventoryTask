package com.example.inventory.service.impl;


import java.math.BigDecimal;
import java.util.UUID;

import com.example.inventory.domain.*;
import com.example.inventory.domain.enums.VehicleStatus;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.repository.VehicleRepository;
import com.example.inventory.repository.spec.VehicleSpecification;
import com.example.inventory.service.VehicleService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;


/**
* Vehicle service implementation with filtering.
*/
@Service
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository vehicleRepository;
    private final DealerRepository dealerRepository;

    
    
    public VehicleServiceImpl(
            VehicleRepository vehicleRepository,
            DealerRepository dealerRepository
    ) {
        this.vehicleRepository = vehicleRepository;
        this.dealerRepository = dealerRepository;
    }

    @Override
    public Vehicle createVehicle(String tenantId, Vehicle vehicle) {

        Dealer dealer = dealerRepository.findById(vehicle.getDealerId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Dealer not found"));

        if (!dealer.getTenantId().equals(tenantId))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Dealer belongs to another tenant");

        vehicle.setTenantId(tenantId);
        vehicle.setDealer(dealer);

        return vehicleRepository.save(vehicle);
    }

    @Override
    public Vehicle getVehicle(String tenantId, UUID id) {

        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        if (!vehicle.getTenantId().equals(tenantId))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);

        return vehicle;
    }

    @Override
    public Page<Vehicle> getVehicles(
            String tenantId,
            String model,
            VehicleStatus status,
            BigDecimal priceMin,
            BigDecimal priceMax,
            Pageable pageable
    ) {

        Specification<Vehicle> spec = Specification
                .where(VehicleSpecification.tenantEquals(tenantId))
                .and(VehicleSpecification.modelContains(model))
                .and(VehicleSpecification.statusEquals(status))
                .and(VehicleSpecification.priceMin(priceMin))
                .and(VehicleSpecification.priceMax(priceMax));

        return vehicleRepository.findAll(spec, pageable);
    }

    @Override
    public Vehicle updateVehicle(String tenantId, UUID id, Vehicle update) {

        Vehicle vehicle = getVehicle(tenantId, id);

        vehicle.setModel(update.getModel());
        vehicle.setPrice(update.getPrice());
        vehicle.setStatus(update.getStatus());

        return vehicleRepository.save(vehicle);
    }

    @Override
    public void deleteVehicle(String tenantId, UUID id) {

        Vehicle vehicle = getVehicle(tenantId, id);

        vehicleRepository.delete(vehicle);
    }
}