package com.example.inventory.repository.spec;

import java.math.BigDecimal;

import org.springframework.data.jpa.domain.Specification;

import com.example.inventory.domain.Vehicle;
import com.example.inventory.domain.enums.SubscriptionType;
import com.example.inventory.domain.enums.VehicleStatus;


/**
* Dynamic filtering specifications for vehicles.
*/
public class VehicleSpecification {

    public static Specification<Vehicle> tenantEquals(String tenantId) {
        return (root, query, cb) ->
                cb.equal(root.get("tenantId"), tenantId);
    }

    public static Specification<Vehicle> modelContains(String model) {
        return (root, query, cb) -> {
            if (model == null)
                return cb.conjunction();

            return cb.like(
                    cb.lower(root.get("model")),
                    "%" + model.toLowerCase() + "%"
            );
        };
    }

    public static Specification<Vehicle> statusEquals(VehicleStatus status) {
        return (root, query, cb) -> {
            if (status == null)
                return cb.conjunction();

            return cb.equal(root.get("status"), status);
        };
    }

    public static Specification<Vehicle> priceMin(BigDecimal min) {
        return (root, query, cb) -> {
            if (min == null)
                return cb.conjunction();

            return cb.greaterThanOrEqualTo(root.get("price"), min);
        };
    }

    public static Specification<Vehicle> priceMax(BigDecimal max) {
        return (root, query, cb) -> {
            if (max == null)
                return cb.conjunction();

            return cb.lessThanOrEqualTo(root.get("price"), max);
        };
    }
}