package com.example.inventory.domain;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

import com.example.inventory.domain.enums.VehicleStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "vehicles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vehicle {

    @Id
    @GeneratedValue
    private UUID id;

    /*
     * Tenant identifier
     */
    @Column(nullable = false)
    private String tenantId;

    /*
     * Dealer owning the vehicle
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dealer_id")
    @JsonIgnore
    private Dealer dealer;

    private String model;

    private BigDecimal price;

    @Enumerated(EnumType.STRING)
    private VehicleStatus status;
    
    
    
    @Transient
    private UUID dealerId;

    public UUID getDealerId() {
        return dealerId;
    }

    public void setDealerId(UUID dealerId) {
        this.dealerId = dealerId;
    }


}