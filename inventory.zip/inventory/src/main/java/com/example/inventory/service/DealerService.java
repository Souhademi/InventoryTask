package com.example.inventory.service;

import com.example.inventory.domain.Dealer;
import com.example.inventory.domain.enums.SubscriptionType;

import com.example.inventory.repository.DealerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;




/**
* Dealer business logic.
*/
public interface DealerService {

    Dealer createDealer(String tenantId, Dealer dealer);

  Page<Dealer> getAllDealers(String tenantId, Pageable pageable);

    Dealer getDealerById(String tenantId, UUID id);

    Dealer updateDealer(String tenantId, UUID id, Dealer dealer);

    void deleteDealer(String tenantId, UUID id);

	Map<String, Long> countBySubscription();

	//Page<Dealer> getAllDealers(Pageable pageable);
}