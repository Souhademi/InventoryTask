package com.example.inventory.controller;

import com.example.inventory.domain.Dealer;
import com.example.inventory.domain.Vehicle;
import com.example.inventory.domain.enums.VehicleStatus;

import com.example.inventory.service.VehicleService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


/**
* Vehicle REST endpoints with filters.
*/
@RestController
@RequestMapping("/vehicles")
public class VehicleController {

    private final VehicleService vehicleService;

    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @PostMapping
    public Vehicle createVehicle(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @RequestBody Vehicle vehicle
    ) {
        return vehicleService.createVehicle(tenantId, vehicle);
    }

    @GetMapping("/{id}")
    public Vehicle getVehicle(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @PathVariable UUID id
    ) {
        return vehicleService.getVehicle(tenantId, id);
    }

    // Filter with model, status, price Max or Min 
    @GetMapping
    public Page<Vehicle> getVehicles(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @RequestParam(required = false) String model,
            @RequestParam(required = false) VehicleStatus status,
            @RequestParam(required = false) BigDecimal priceMin,
            @RequestParam(required = false) BigDecimal priceMax,
            Pageable pageable
    ) {
        return vehicleService.getVehicles(
        // /vehicles?page=0&size=5&sort=price,desc&status=SOLD
                tenantId,
                model,
                status,
                priceMin,
                priceMax,
                pageable
        );
    }

    @PatchMapping("/{id}")
    public Vehicle updateVehicle(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @PathVariable UUID id,
            @RequestBody Vehicle vehicle
    ) {
        return vehicleService.updateVehicle(tenantId, id, vehicle);
    }

    @DeleteMapping("/{id}")
    public void deleteVehicle(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @PathVariable UUID id
    ) {
        vehicleService.deleteVehicle(tenantId, id);
    }
}
