package com.example.inventory.domain.enums;

public enum VehicleStatus {

    AVAILABLE,
    SOLD
}