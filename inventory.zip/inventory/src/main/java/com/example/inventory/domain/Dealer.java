package com.example.inventory.domain;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

import com.example.inventory.domain.enums.SubscriptionType;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "dealers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Dealer {

    @Id
    @GeneratedValue
    private UUID id;

    /*
     * Tenant identifier
     */
    @Column(nullable = false)
    private String tenantId;

    @Column(nullable = false)
    private String name;

    private String email;

    @Enumerated(EnumType.STRING)
    private SubscriptionType subscriptionType;

}
