package com.example.inventory.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.example.inventory.domain.enums.SubscriptionType;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.service.AdminService;
import com.example.inventory.service.DealerService;

import lombok.RequiredArgsConstructor;

import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/admin")


public class AdminController {

	private final DealerRepository dealerRepository;

    AdminController(DealerRepository dealerRepository) {
        this.dealerRepository = dealerRepository;
    }
   

    //@PreAuthorize("hasRole('GLOBAL_ADMIN')")
    @GetMapping("/dealers/countBySubscription")
    public Map<String, Long> countBySubscription(       
    		@RequestHeader("X-Tenant-Id") String tenantId,
            @RequestHeader(value = "Role", required = true) String role) {

        long basic = dealerRepository.countBySubscriptionType(SubscriptionType.BASIC);
        long premium = dealerRepository.countBySubscriptionType(SubscriptionType.PREMIUM);

        return Map.of(
                "BASIC", basic,
                "PREMIUM", premium
        );

    }
}
