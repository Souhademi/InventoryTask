package com.example.inventory.repository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventory.domain.Dealer;
import com.example.inventory.domain.enums.SubscriptionType;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


/**
* Repository for Dealer persistence.
*/
public interface DealerRepository extends JpaRepository<Dealer, UUID> {

    /**
     * Fetch dealers belonging to a tenant.
     */
    Page<Dealer> findByTenantId(String tenantId, Pageable pageable);

    /**
     * Count dealers by subscription plan.
     */
    long countBySubscriptionType(SubscriptionType subscriptionType);
    
    Optional<Dealer> findByIdAndTenantId(UUID id, String tenantId);
}