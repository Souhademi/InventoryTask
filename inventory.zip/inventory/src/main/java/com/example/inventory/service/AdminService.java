package com.example.inventory.service;

import com.example.inventory.domain.enums.SubscriptionType;
import com.example.inventory.repository.DealerRepository;

import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class AdminService {

    private final DealerRepository dealerRepository;

    public AdminService(DealerRepository dealerRepository) {
        this.dealerRepository = dealerRepository;
    }

    public Map<String, Long> countBySubscription() {

        long basic = dealerRepository.findAll()
                .stream()
                .filter(d -> d.getSubscriptionType() == SubscriptionType.BASIC)
                .count();

        long premium = dealerRepository.findAll()
                .stream()
                .filter(d -> d.getSubscriptionType() == SubscriptionType.PREMIUM)
                .count();

        return Map.of(
                "BASIC", basic,
                "PREMIUM", premium
        );
    }
}
