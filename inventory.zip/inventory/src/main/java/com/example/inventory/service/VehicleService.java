package com.example.inventory.service;



import lombok.RequiredArgsConstructor;

import com.example.inventory.domain.Dealer;
import com.example.inventory.domain.Vehicle;
import com.example.inventory.domain.enums.SubscriptionType;
import com.example.inventory.domain.enums.VehicleStatus;
//import com.example.inventory.dto.*;

import org.springframework.data.domain.*;

import java.math.BigDecimal;
import java.util.UUID;

/**
* Vehicle service.
*/
public interface VehicleService {

    Vehicle createVehicle(String tenantId, Vehicle vehicle);

    Vehicle getVehicle(String tenantId, UUID id);

    Page<Vehicle> getVehicles(
            String tenantId,
            String model,
            VehicleStatus status,
            BigDecimal priceMin,
            BigDecimal priceMax,
            Pageable pageable
    );

    Vehicle updateVehicle(String tenantId, UUID id, Vehicle vehicle);

    void deleteVehicle(String tenantId, UUID id);
}
