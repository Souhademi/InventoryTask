package com.example.inventory.controller;



import org.springframework.web.bind.annotation.*;

import com.example.inventory.domain.Dealer;
import com.example.inventory.domain.Vehicle;
import com.example.inventory.service.DealerService;
import com.example.inventory.service.VehicleService;

import jakarta.validation.Valid;

import java.util.UUID;

import com.example.inventory.service.DealerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
* Dealer REST endpoints.
*/
@RestController
@RequestMapping("/dealers")
public class DealerController {

    private final DealerService dealerService;

    public DealerController(DealerService dealerService) {
        this.dealerService = dealerService;
    }

    @PostMapping
    public Dealer createDealer(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @RequestBody Dealer dealer
    ) {
        return dealerService.createDealer(tenantId, dealer);
    }
  

    @GetMapping
    public Page<Dealer> getAllDealers(
            @RequestHeader("X-Tenant-Id") String tenantId,
            Pageable pageable
    ) {
        return dealerService.getAllDealers(tenantId, pageable);
    }


    @GetMapping("/{id}")
    public Dealer getDealer(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @PathVariable UUID id
    ) {
        return dealerService.getDealerById(tenantId, id);
    }

    @PatchMapping("/{id}")
    public Dealer updateDealer(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @PathVariable UUID id,
            @RequestBody Dealer dealer
    ) {
        return dealerService.updateDealer(tenantId, id, dealer);
    }

    @DeleteMapping("/{id}")
    public void deleteDealer(
            @RequestHeader("X-Tenant-Id") String tenantId,
            @PathVariable UUID id
    ) {
        dealerService.deleteDealer(tenantId, id);
    }
}