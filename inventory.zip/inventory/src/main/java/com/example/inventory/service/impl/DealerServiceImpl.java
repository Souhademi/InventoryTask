package com.example.inventory.service.impl;


import com.example.inventory.domain.Dealer;
import com.example.inventory.domain.Vehicle;
import com.example.inventory.domain.enums.SubscriptionType;
import com.example.inventory.repository.DealerRepository;
import com.example.inventory.service.DealerService;
import com.example.inventory.tenant.TenantContext;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
* Implementation of dealer business logic.
*/
@Service
public class DealerServiceImpl implements DealerService {

    private final DealerRepository dealerRepository;

    public DealerServiceImpl(DealerRepository dealerRepository) {
        this.dealerRepository = dealerRepository;
    }

    @Override
    public Dealer createDealer(String tenantId, Dealer dealer) {
        dealer.setTenantId(tenantId);
        return dealerRepository.save(dealer);
    }

    @Override
    public Page<Dealer> getAllDealers(String tenantId, Pageable pageable) {
        return dealerRepository.findByTenantId(tenantId, pageable);
    }
    

    @Override
    public Dealer getDealerById(String tenantId, UUID id) {

        Dealer dealer = dealerRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        if (!dealer.getTenantId().equals(tenantId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }

        return dealer;
    }

    @Override
    public Dealer updateDealer(String tenantId, UUID id, Dealer update) {

        Dealer dealer = getDealerById(tenantId, id);

        dealer.setName(update.getName());
        dealer.setEmail(update.getEmail());
        dealer.setSubscriptionType(update.getSubscriptionType());

        return dealerRepository.save(dealer);
    }

    @Override
    public void deleteDealer(String tenantId, UUID id) {

        Dealer dealer = getDealerById(tenantId, id);

        dealerRepository.delete(dealer);
    }

    @Override
    public Map<String, Long> countBySubscription() {

        long basic = dealerRepository.countBySubscriptionType(SubscriptionType.BASIC);
        long premium = dealerRepository.countBySubscriptionType(SubscriptionType.PREMIUM);

        return Map.of(
                "BASIC", basic,
                "PREMIUM", premium
        );
    }
}